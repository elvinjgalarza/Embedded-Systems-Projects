// put prototypes for public functions, explain what it does
// put your names here, date
void ADC_Init(void);

uint32_t ADC_In(void);
