// put prototypes for public functions, explain what it does
// put your names here, date
void DAC_Init(void);

void DAC_Out(uint32_t data);
